// src/routes/apiCarts.router.js
import { Router } from 'express';
import { CartController } from '../controllers/CartController.js';
import { auth } from '../middleware/auth.js';
import { passportCall } from '../utils.js';

export const router = Router();

router.post('/', CartController.createEmptyCart); 

router.get('/:cid', CartController.getCartById);

router.post('/:cid/product/:pid', passportCall('current'), CartController.addProductToExistingCart);

router.post('/:cid/purchase', passportCall('current'), CartController.purchaseCart)

router.delete('/:cid/product/:pid', CartController.deleteProductFromCart);

router.delete('/', CartController.clearCart);

router.get('/', passportCall('current'), auth('admin'), CartController.getAllCarts);

router.put('/:cid', CartController.updateCart);

router.put('/:cid/product/:pid', CartController.updateProductQuantity);


