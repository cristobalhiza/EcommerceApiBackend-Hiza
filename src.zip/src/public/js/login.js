const inputEmail = document.getElementById('email');
const inputPassword = document.getElementById('password');
const btnSubmit = document.getElementById('btnSubmit');
const divMensajes = document.getElementById('mensajes');

// Escuchar el evento click en el botón de login
btnSubmit.addEventListener('click', async (e) => {
    e.preventDefault();

    // Captura y limpieza de los valores de los inputs
    const email = inputEmail.value.trim();
    const password = inputPassword.value.trim();

    // Validaciones básicas
    if (!email || !password) {
        mostrarMensaje('Por favor, completa todos los campos obligatorios.');
        return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        mostrarMensaje('Introduce un email válido.');
        return;
    }

    // Crear el cuerpo de la solicitud
    const body = { email, password };

    try {
        // Llamada al endpoint de login
        const respuesta = await fetch('/api/sessions/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });

        // Manejar errores del servidor
        if (respuesta.status === 401) {
            mostrarMensaje('Credenciales incorrectas. Inténtalo de nuevo.');
            return;
        }

        if (!respuesta.ok) {
            mostrarMensaje('Ocurrió un error al procesar la solicitud. Por favor, intenta más tarde.');
            console.error('Error en la respuesta:', await respuesta.text());
            return;
        }

        // Procesar la respuesta del servidor
        const datos = await respuesta.json();

        // Verificar si el login fue exitoso
        if (datos.usuarioLogeado) {
            console.log('Usuario logueado:', datos.usuarioLogeado);

            // Redirigir a la página de cuenta
            window.location.href = '/current';
        } else {
            mostrarMensaje('Error inesperado. Inténtalo de nuevo.');
        }
    } catch (error) {
        mostrarMensaje('Error de conexión con el servidor. Por favor, inténtalo más tarde.');
        console.error('Error al hacer la solicitud:', error);
    }
});

// Mostrar mensajes en la interfaz
function mostrarMensaje(mensaje) {
    divMensajes.textContent = mensaje;
    setTimeout(() => {
        divMensajes.textContent = '';
    }, 6000);
}
document.addEventListener('DOMContentLoaded', () => {
    const getQueryParam = (param) => {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    };

    const mensaje = getQueryParam('mensaje');
    if (mensaje) {
        mostrarMensaje(mensaje);
    }
});
